

url -k 'https://127.0.0.1:9200/_cluster/health' --user 'elastic:elastic' | jq '.'


curl -X GET "http://127.0.0.1:9200/stations/_search" -d'
{
  "query": { "match_all": {} }
}' --user 'elastic:elastic' | jq '.'